#!/bin/sh

# 刷入 a分区

dd if="/sdcard/root/magisk_patched-a.img" of=/dev/block/by-name/init_boot_a bs=1M